import java.util.Date;

public class Block {

  public String hash;
  public String previousHash;
  private String data; //our data will be a simple message.
  private long timeStamp; //as number of milliseconds since 1/1/1970.

  //Block Constructor.
  public Block(String data,String previousHash ) {
    this.data = data;
    this.previousHash = previousHash;
    this.timeStamp = new Date().getTime();
  }
}
import java.security.MessageDigest;
public class StringUtil {
    public static String applySha256(String input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(input.getBytes("UTF-8"));
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
public class Block {
    public String hash;
    public String previousHash;
    private String data;
    private long timeStamp;

    public Block(String data, String previousHash) {
        this.data = data;
        this.previousHash = previousHash;
        this.timeStamp = new Date().getTime();
        this.hash = calculateHash();
    }

    public String calculateHash() {
        return StringUtil.applySha256(previousHash + Long.toString(timeStamp) + data);
    }
}
public class NoobChain {
    public static void main(String[] args) {
        Block genesisBlock = new Block("Hi, I'm the first block", "0");
        System.out.println("Hash for block 1: " + genesisBlock.hash);

        Block secondBlock = new Block("Yo, I'm the second block", genesisBlock.hash);
        System.out.println("Hash for block 2: " + secondBlock.hash);

        Block thirdBlock = new Block("Hey, I'm the third block", secondBlock.hash);
        System.out.println("Hash for block 3: " + thirdBlock.hash);
    }
}

public class NoobChain {

  public static void main(String[] args) {

    Block genesisBlock = new Block("Hi im the first block", "0");
    System.out.println("Hash for block 1 : " + genesisBlock.hash);

    Block secondBlock = new Block("Yo im the second block",genesisBlock.hash);
    System.out.println("Hash for block 2 : " + secondBlock.hash);

    Block thirdBlock = new Block("Hey im the third block",secondBlock.hash);
    System.out.println("Hash for block 3 : " + thirdBlock.hash);

  }
}